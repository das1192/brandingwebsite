$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').focus()
})