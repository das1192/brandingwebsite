<?php


define("DBHOST","localhost");

define("DBUSER","tecnotro_admin");

define("DBPASS","tecnotronadmin");

define("DBNAME","tecnotro_tecno");



?>